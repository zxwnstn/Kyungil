#include "Etc/stdafx.h"
#include "ItemManager.h"
#include "HomeWorkClass/HomeWorkType.h"
DEFINITION_SINGLE(ItemManager)

ItemManager::ItemManager()
{
}


ItemManager::~ItemManager()
{
}

bool ItemManager::init()
{
	ItemProtoType[0] = Item(ItemType::ItemRangeUp);
	ItemProtoType[1] = Item(ItemType::ItemSpeedUp);
	ItemProtoType[2] = Item(ItemType::ItemBombLimitUp);
	ItemProtoType[3] = Item(ItemType::ItemKick);
	ItemProtoType[4] = Item(ItemType::ItemDart);
	ItemProtoType[5] = Item(ItemType::ItemNone);
	ItemProtoType[6] = Item(ItemType::ItemNone);
	ItemProtoType[7] = Item(ItemType::ItemNone);
	ItemProtoType[8] = Item(ItemType::ItemNone);
	ItemProtoType[9] = Item(ItemType::ItemNone);
	return true;
}

void ItemManager::update(float deltaTime)
{
	for (auto& e : items)
		e->update(deltaTime);
}

void ItemManager::render(HDC hdc)
{
	for (auto& e : items)
		e->render(hdc);
}

void ItemManager::debugRender(HDC hdc)
{
	for (auto& e : items)
		e->debugRender(hdc);
}

void ItemManager::release()
{
	items.clear();
}

void ItemManager::collision()
{
}

void ItemManager::push_Item(shared_ptr<Item> item)
{
	items.push_back(item);
}

void ItemManager::erase_Item(shared_ptr<Item> item)
{
	for (auto it = items.begin(); it != items.end(); ++it)
		if (*it == item) 
			items.erase(it);
}