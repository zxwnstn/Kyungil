#pragma once
#define BIT(x) (1 << x)

#define BLOCK_WIDTH 30
#define BLOCK_HEIGHT 30
#define NUM_BLOCK_X 21
#define NUM_BLOCK_Y 21

struct BlockPosition {
	int x, y;
	BlockPosition() {}
	BlockPosition(int _x, int _y) {
		x = _x;
		y = _y;
	}
};

enum class BoomState {
	BoomCenter,
	BoomHorizenRight,
	BoomHorizenRightEnd,
	BoomHorizenLeft,
	BoomHorizenLeftEnd,
	BoomVerticalUp,
	BoomVerticalUpEnd,
	BoomVerticalDown,
	BoomVerticalDownEnd,
};

enum class BlockType {
	BlockHard,
	BlockSoft,
	BlockNone
};

enum class ItemType {
	ItemRangeUp,
	ItemSpeedUp,
	ItemBombLimitUp,
	ItemKick,
	ItemDart,
	ItemNone
};

enum class CharacterState {
	OnLeftMove	= BIT(0) ,
	OnRightMove	= BIT(1),
	OnUpMove	= BIT(2),
	OnDownMove	= BIT(3),
	OnIdle		= BIT(4),
	OnRide		= BIT(5),
	InBallon	= BIT(6)
};